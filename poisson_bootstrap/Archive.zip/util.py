#!/usr/bin/env python3
"""
Utility for metric computations.
"""
from __future__ import annotations

import collections
import functools
import sys
from math import isinf, isnan
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union, Tuple

import numpy as np
import pandas as pd
from fblearner.flow import flow_init
from fblearner.flow.api import types
from fblearner.flow.projects.fluent2.definition.task_type import (
    ClassPredictionTaskType,
    ExclusiveMultiClassPredictionTaskType,
    ExclusiveTwoClassPredictionTaskType,
    MultiClassIntegerPredictionTaskType,
    MultiClassPredictionTaskType,
    SparselyLabeledMultiClassPredictionTaskType,
    TaskType,
)
from fblearner.flow.projects.fluent2.definition.transformer import Transformer
from fblearner.flow.projects.fluent2.workflows import const

# @dep=//fblearner/flow/util:hive
from fblearner.flow.util.hive import create_python_object, gen_sparse_python_object
from fblearner.flow.util.python_utils import (
    NonRetryableException,
    PickleableLogger as Logger,
    abstract,
    static,
)
from libfb.py.lazy_import import lazy_import
from six import iteritems
from sklearn.preprocessing import label_binarize


workspace = lazy_import("caffe2.python", "workspace")

if TYPE_CHECKING:
    from caffe2.python import schema
else:
    schema = lazy_import("caffe2.python.schema")

log = Logger(__name__)

# Used to present very small or very large number.
MINUS_INF = -1000000000.0
INF = 1000000000.0
N_BOOTSTRAPS: int = 5000


# Extractors.


@abstract
class EvaluationSetExtractor(object):
    """
    Extract labels, scores, weights from evaluation set
    """

    def __init__(self, transformer, evaluation_set, label_func):
        """
        Create a EvaluationSetExtractor that, given the label function,
        extracts labels, scores and weights for a given class.

        Args:
            transformer:     Transformer definition
            evaluation_set:  A map from evaluation query to a DataFrame with
                             transformer output and label
            label_func:      A function to get labels from evaluation_set
        """
        self.evaluation_set = evaluation_set
        self.label_func = label_func
        self.feature_id = transformer.get_output_features().score.id

    def get_labels_for_class(self, klass):
        return self.label_func(self.evaluation_set, klass)

    def get_scores_for_class(self, klass):
        return get_validated_categorical_score(
            self.evaluation_set,
            "string_weighted_multi_categorical_features",
            self.feature_id,
            klass,
        )

    def get_weights(self):
        return self.evaluation_set.weight.values

    def get_weights_for_class(self, klass):
        return self.evaluation_set.weight.values


class ExclusiveMultiClassEvaluationSetExtractor(EvaluationSetExtractor):
    def __init__(self, transformer, evaluation_set):
        EvaluationSetExtractor.__init__(
            self, transformer, evaluation_set, get_equals_class_labels
        )


class MultiClassEvaluationSetExtractor(EvaluationSetExtractor):
    def __init__(self, transformer, evaluation_set):
        EvaluationSetExtractor.__init__(
            self, transformer, evaluation_set, get_contains_class_labels
        )


class SparselyLabeledMultiClassEvaluationSetExtractor(EvaluationSetExtractor):
    def __init__(self, transformer, evaluation_set):
        EvaluationSetExtractor.__init__(self, transformer, evaluation_set, None)
        self.has_label = {}

    def get_labels_for_class(self, klass):
        return get_labels_for_class(self.evaluation_set, klass)

    def get_scores_for_class(self, klass):
        has_label = get_contains_class_labels(self.evaluation_set, klass)
        return get_validated_categorical_score(
            self.evaluation_set,
            "string_weighted_multi_categorical_features",
            self.feature_id,
            klass,
        )[has_label]

    def get_weights_for_class(self, klass):
        has_label = get_contains_class_labels(self.evaluation_set, klass)
        return self.evaluation_set.weight[has_label].values


# Factory.


@static
class EvaluationSetExtractorFactory(object):
    REGISTRY = {
        ExclusiveMultiClassPredictionTaskType: ExclusiveMultiClassEvaluationSetExtractor,
        MultiClassPredictionTaskType: MultiClassEvaluationSetExtractor,
        SparselyLabeledMultiClassPredictionTaskType: SparselyLabeledMultiClassEvaluationSetExtractor,
    }

    @classmethod
    def get(cls, task):
        for task_type, extractor in iteritems(cls.REGISTRY):
            if isinstance(task, task_type):
                return extractor
        raise NotImplementedError


# Others.
def get_labels_for_class(evaluation_set: pd.DataFrame, klass: Any) -> pd.Series:
    if _label_class_column(klass) not in evaluation_set:
        return pd.Series([])
    has_label = get_contains_class_labels(evaluation_set, klass)
    return evaluation_set[_label_class_column(klass)][has_label].infer_objects()


def get_valid_scores(scores):
    """
    This method cleans up scores such as '-Infinity' that are output by DocNN
    Input Arguments:
        scores: Pandas series or a dataframe in which each element is a scalar.
    Output:
        Cleaned Pandas series of scores. If dataframe was passed, the result
        is a series of lists.
    """

    def get_valid_score(score):
        if score is None or isinstance(score, float) and (isinf(score) or isnan(score)):
            return 0.0
        elif isinstance(score, list):
            return [get_valid_score(value) for value in score]
        else:
            return score

    if isinstance(scores, pd.DataFrame):
        valid_columns = [
            scores[column].map(get_valid_score).tolist()
            for column in scores.columns.values
        ]
        # TODO (T57451813): not good to change returned type here. This is
        # for backward compatibility and to match with get_multi_feature_values
        return pd.Series(list(zip(*valid_columns)))
    return scores.map(get_valid_score)


def get_feature_values(
    evaluation_set: pd.DataFrame, column: str, feature_id: int
) -> pd.Series:
    if "weighted" in column:
        raise Exception("Cannot requested weighted columns. Use helper functions.")
    return _get_feature_values(evaluation_set, column, feature_id)


def _get_feature_values(
    evaluation_set: pd.DataFrame, column: str, feature_id: int
) -> pd.Series:
    """
    Returns pandas Series for feature column[feature_id]. If the type is a
    map type (categorical types), the series is asserted to have no None values.
    """
    series = evaluation_set[f"{column}_{feature_id}"]

    # Check dict types for Nones.
    if types.issubtype(
        const.V2_FEATURES_DATASET_PATH_TYPE.schema[column].ValueType,
        types.DICT(types.ANY, types.ANY),
    ):
        none_values = series[series.isnull()]
        if not none_values.empty:
            raise NonRetryableException(
                f"Found {none_values.shape[0]} null values in {column}[{feature_id}]. "
                "Set filter_empty_features=True for SimpleEvaluation to automatically "
                "remove empty values."
            )

    return series


def get_multi_feature_values(
    evaluation_set: pd.DataFrame, column: str, feature_ids: List[int]
):
    return evaluation_set[[f"{column}_{feature_id}" for feature_id in feature_ids]]


def _get_column_to_feature_ids(features):
    column_to_feature_ids = collections.defaultdict(list)
    for feature in features:
        column_to_feature_ids[feature.get_type_snake_name()].append(feature.id)
    return column_to_feature_ids


def extract_feature_data_frames(transformer, features=None):
    """
    Return function that maps caffe2 blobs produced by the HiveReader
    into pandas dataframes, where there is one column per feature id.
    Feature column is named as "{feature_column}_{id}".
    Can be used as custom_mapper_fun in Hive.read_to_data_frame
    """
    column_to_feature_ids = _get_column_to_feature_ids(
        features or transformer.get_output_features()
    )
    return functools.partial(
        create_data_frame_from_caffe2_blobs, column_to_feature_ids=column_to_feature_ids
    )


def create_data_frame_from_caffe2_blobs(
    fields: Dict[str, schema.Field],
    column_names: List[str],
    column_to_feature_ids: Dict[str, List[int]],
) -> pd.DataFrame:
    df = pd.DataFrame()
    for column_name in column_names:
        column_df = create_pandas_series(
            fields[column_name], column_name, column_to_feature_ids[column_name]
        )
        if column_to_feature_ids[column_name]:
            for feature_id in column_to_feature_ids[column_name]:
                df_column_name = f"{column_name}_{feature_id}"
                df[df_column_name] = column_df[df_column_name]
        else:
            df[column_name] = column_df
    return df


def create_pandas_series(field: schema.Field, column_name: str, feature_ids: List[int]):
    from fblearner.flow.util.hive import utf8_decode, gen_sparse_python_object

    if len(feature_ids):
        # For feature data, extract into columnar pandas dataframes.
        # pyre-fixme[16]: `Field` has no attribute `lengths`.
        lengths = workspace.FetchBlob(field.lengths.get())
        return _extract_pandas_dataframe_from_feature_blobs(
            # pyre-fixme[16]: `Field` has no attribute `__getitem__`.
            field["values"],
            column_name,
            lengths,
            feature_ids,
        )
    # For label column we want to intern strings
    if column_name == "label":
        if isinstance(field, schema.Scalar) and column_name == "label":
            return utf8_decode(workspace.FetchBlob(field.get()), intern_strings=True)
        elif isinstance(field, schema.List):
            lengths = workspace.FetchBlob(field.lengths.get())
            return list(
                gen_sparse_python_object(field["values"], lengths, intern_strings=True)
            )
    return create_python_object(field)


def _extract_pandas_dataframe_from_feature_blobs(
    field: schema.Struct, column_name: str, lengths: List[int], feature_ids: List[int]
):
    """
    Create a dataframe with columns as '{column_name}_{feature_id}' that contains
    the feature values as pandas series. The data is extracted from caffe2
    blobs produced by the HiveReader operator using functions in
    flow/util/hive.py.
    """
    assert set(field.fields.keys()) == {"keys", "values"}
    keys_gen = gen_sparse_python_object(field.keys, lengths)
    values_gen = gen_sparse_python_object(field.values, lengths)
    feature_id_to_values = {feature_id: [] for feature_id in feature_ids}

    for keys in keys_gen:
        values = next(values_gen)
        for key, value in zip(keys, values):
            feature_id_to_values[key].append(value)

        for missing_key in set(feature_ids) - set(keys):
            feature_id_to_values[missing_key].append(None)
    return pd.DataFrame(
        {
            f"{column_name}_{feature_id}": feature_id_to_values[feature_id]
            for feature_id in feature_ids
        }
    )


def get_equals_class_labels(evaluation_set: pd.DataFrame, klass: Any):
    """
    Returns boolean label which is True if the label == klass.
    """
    return evaluation_set.label == klass


def get_contains_class_labels(evaluation_set: pd.DataFrame, klass: Any):
    """
    Returns boolean label which is True if the klass is contained
    in the label, which is a list of classes.
    """
    if "label" in evaluation_set:  # The label has single label type.
        return evaluation_set.label == klass
    else:
        column_name = _label_class_column(klass)
        return (
            evaluation_set[_label_class_column(klass)].notnull()
            if column_name in evaluation_set
            else pd.Series([False] * evaluation_set.shape[0], dtype="bool")
        )


def get_validated_categorical_score(
    evaluation_set: pd.DataFrame,
    feature_column: str,
    feature_id: int,
    klass: Union[int, str],
    missing_value: Optional[Any] = None,
) -> pd.Series:
    """
    Returns score for class klass from weighted categorical features.
    Inf/Nans are converted to zeros.
    """
    if feature_column in ["float_tensor_features", "int_tensor_features"]:
        return get_valid_scores(
            evaluation_set[f"{feature_column}_{feature_id}"].map(lambda row: row[klass])
        )
    class_column = _category_class_column(feature_column, feature_id, klass)
    if class_column in evaluation_set.columns.values:
        return evaluation_set[class_column]
    else:
        return pd.Series([missing_value] * evaluation_set.shape[0])


def get_validated_effective_score(
    evaluation_set: pd.DataFrame,
    feature_column: str,
    feature_id: int,
    klass: Union[int, str],
):
    """
    Returns score for class klass from weighted categorical features if it is
    the maximum score for the row. Otherwise returns MINUS_INF.
    """
    # TODO: cache?
    classes = _get_classes_for_weighted_categorical(
        evaluation_set, feature_column, feature_id
    )
    scores = evaluation_set[_category_class_column(feature_column, feature_id, klass)]
    df = evaluation_set[
        [_category_class_column(feature_column, feature_id, kl) for kl in classes]
    ]
    maxs = df.max(axis=1)
    return (scores == maxs) * scores + (scores < maxs) * MINUS_INF


def get_validated_effective_score_min(
    evaluation_set: pd.DataFrame,
    feature_column: str,
    feature_id: int,
    klass: Union[int, str],
):
    """
    Returns score for class klass from weighted categorical features if it is
    the minimum score for the row. Otherwise returns INF.
    """
    classes = _get_classes_for_weighted_categorical(
        evaluation_set, feature_column, feature_id
    )
    scores = evaluation_set[_category_class_column(feature_column, feature_id, klass)]
    df = evaluation_set[
        [_category_class_column(feature_column, feature_id, kl) for kl in classes]
    ]
    mins = df.min(axis=1)
    return (scores == mins) * scores + (scores > mins) * INF


def get_best_category_prediction(
    evaluation_set: pd.DataFrame, feature_column: str, feature_id: int
) -> List[Union[int, str]]:
    """
    For each row, returns the best category.
    """
    classes = _get_classes_for_weighted_categorical(
        evaluation_set, feature_column, feature_id
    )
    df = evaluation_set[
        [_category_class_column(feature_column, feature_id, kl) for kl in classes]
    ]
    df = df.rename(
        # pyre-fixme[6]: Expected
        #  `Union[typing.Callable[[Optional[typing.Hashable]],
        #  Optional[typing.Hashable]], None, typing.Mapping[Optional[typing.Hashable],
        #  typing.Any]]` for 1st param but got `Dict[str, Union[int, str]]`.
        columns={
            _category_class_column(feature_column, feature_id, kl): kl for kl in classes
        }
    )
    argmaxs = df.idxmax(axis=1)
    return argmaxs.to_list()


def get_max_k_categories(
    evaluation_set: pd.DataFrame, feature_column: str, feature_id: int, k: int
):
    classes = _get_classes_for_weighted_categorical(
        evaluation_set, feature_column, feature_id
    )
    columns = [_category_class_column(feature_column, feature_id, kl) for kl in classes]
    # pyre-fixme[16]: `None` has no attribute `values`.
    matrix = evaluation_set[columns].rename_axis("ID").values
    sort_indices = matrix.argsort(axis=1)  # ascending order
    max_k_indices = list(sort_indices[:, -k:])
    return [[classes[j] for j in col_indices] for col_indices in max_k_indices]


def get_categorical_feature_maps(
    evaluation_set: pd.DataFrame, feature_column: str, feature_id: int
) -> pd.Series:
    log.warning(
        "THIS METRICS DEFINITION IS USING VERY INEFFICIENT get_categorical_feature_maps()"
    )
    log.warning(
        "Use get_validated_effective_score_max(), get_validated_effective_score() etc."
    )
    classes = _get_classes_for_weighted_categorical(
        evaluation_set, feature_column, feature_id
    )
    columns = [_category_class_column(feature_column, feature_id, kl) for kl in classes]
    df = evaluation_set[columns]
    classes_and_columns = list(zip(classes, columns))
    return pd.Series(
        [
            {klass: df[column][j] for klass, column in classes_and_columns}
            for j in df.index
        ],
        index=df.index,
    )


def get_class_to_column_map(
    evaluation_set: pd.DataFrame, feature_column: str, feature_id: int
) -> Dict[Union[int, str], str]:
    classes = _get_classes_for_weighted_categorical(
        evaluation_set, feature_column, feature_id
    )
    return {
        kl: _category_class_column(feature_column, feature_id, kl) for kl in classes
    }


def get_categorical_feature_values(
    evaluation_set: pd.DataFrame,
    feature_column: str,
    feature_id: int,
    classes: Optional[List[Union[int, str]]] = None,
    missing_value=0,
) -> np.ndarray:
    if feature_column.endswith("weighted_multi_categorical_features"):
        if classes is None:
            classes = _get_classes_for_weighted_categorical(
                evaluation_set, feature_column, feature_id
            )
        columns = [
            _category_class_column(feature_column, feature_id, kl) for kl in classes
        ]
        df = evaluation_set[columns]
        return np.nan_to_num(df.to_numpy())
    elif feature_column.endswith("tensor_features"):
        arr = np.stack(evaluation_set[f"{feature_column}_{feature_id}"])
        if classes is not None:
            arr = arr[:, classes]
        return np.nan_to_num(arr)
    else:
        raise AssertionError(f"Not supported {feature_column}")


def get_label_class_binary(
    evaluation_set: pd.DataFrame,
    task_type: ClassPredictionTaskType,
    missing_value=0,
    classes: Optional[List[Any]] = None,
) -> np.ndarray:
    if classes is None:
        classes = task_type.classes
    if isinstance(task_type, ExclusiveTwoClassPredictionTaskType):
        ret = np.concatenate(
            [
                (1 - evaluation_set.label.to_numpy()).reshape(-1, 1),
                evaluation_set.label.to_numpy().reshape(-1, 1),
            ],
            axis=1,
        )
    elif (
        isinstance(task_type, ExclusiveMultiClassPredictionTaskType)
        and len(classes) == 2
    ):
        v = label_binarize(evaluation_set.label, classes=classes)
        ret = np.concatenate([(1 - v), v], axis=1)

    elif isinstance(task_type, ExclusiveMultiClassPredictionTaskType):
        ret = label_binarize(evaluation_set.label, classes=classes)
    elif isinstance(
        task_type, (MultiClassPredictionTaskType, MultiClassIntegerPredictionTaskType)
    ):
        return (
            get_label_classes_dataframe(evaluation_set, classes)
            .fillna(value=0)
            .to_numpy(np.int8)
        )
    elif isinstance(task_type, SparselyLabeledMultiClassPredictionTaskType):
        return (
            get_label_classes_dataframe(evaluation_set, classes)
            .fillna(value=missing_value)
            .to_numpy(dtype=np.float)
        )
    else:
        raise AssertionError(f"Unsupported task_type: {task_type}")
    return np.stack(ret)


def get_label_classes_dataframe(
    evaluation_set: pd.DataFrame, classes: List[Any]
) -> pd.DataFrame:
    return evaluation_set[
        [
            _label_class_column(c)
            for c in classes
            if _label_class_column(c) in evaluation_set
        ]
    ].rename(
        columns={
            _label_class_column(klass): str(klass)
            for klass in classes
            if _label_class_column(klass) in evaluation_set
        }
    )


def vectorize_weighted_categorical_features(
    batch: pd.DataFrame, transformer: Transformer
) -> pd.DataFrame:
    """
    Categorical features have structure of map<string|int, float>.
    This converts them to categorical_{feature_id}_{klass} columns, and removes
    the original column. Does the same for the label.
    """
    assert transformer.task_type is not None  # pyre
    # pyre-fixme[16]: `Optional` has no attribute `get_output_feature_names`.
    for output_feature_name in transformer.task_type.get_output_feature_names():
        output_feature = transformer.get_output_features()[output_feature_name]
        if output_feature.get_type_snake_name() in [
            "string_weighted_multi_categorical_features",
            "int_weighted_multi_categorical_features",
        ]:
            feature_dicts = _get_feature_values(
                batch, output_feature.get_type_snake_name(), output_feature.id
            )
            classes = (
                output_feature.categories
                if (hasattr(output_feature, "categories") and output_feature.categories)
                # pyre-fixme[16]: `Optional` has no attribute `classes`.
                else transformer.task_type.classes
            )

            for klass in classes:
                batch[
                    _category_class_column(
                        output_feature.get_type_snake_name(), output_feature.id, klass
                    )
                ] = get_valid_scores(
                    feature_dicts.map(
                        lambda feature_dict: feature_dict[klass]
                        if klass in feature_dict
                        else None
                    )
                )
            batch = batch.drop(
                columns=[f"{output_feature.get_type_snake_name()}_{output_feature.id}"]
            )
    if "label" in batch:
        # pyre-fixme[6]: Expected `TaskType` for 2nd param but got `Optional[TaskType]`.
        return vectorize_categorical_label(batch, transformer.task_type)
    return batch


def vectorize_categorical_label(
    batch: pd.DataFrame, task_type: TaskType
) -> pd.DataFrame:
    """
    Categorical labels of type dict(klass, value) are transfomed into columns per each class.
    """
    assert isinstance(task_type, TaskType)
    if not isinstance(task_type, ClassPredictionTaskType):
        return batch
    if types.issubtype(task_type.get_label_type(), types.DICT(types.ANY, types.ANY)):
        for klass in task_type.classes:
            batch[_label_class_column(klass)] = batch.label.map(
                lambda label_dict: label_dict.get(klass, None)
            )
        batch = batch.drop(columns=["label"])
    elif types.issubtype(task_type.get_label_type(), types.LIST(types.ANY)):
        # List type of labels yield a boolean vector for each class, with None
        # values if the label does not exist.
        for klass in task_type.classes:
            batch[_label_class_column(klass)] = batch.label.map(
                lambda label_list: True if klass in label_list else None
            )
        batch = batch.drop(columns=["label"])
    return batch


def _category_class_column(
    feature_column: str, feature_id: int, klass: Union[int, str]
) -> str:
    return f"{feature_column}_{feature_id}_c_{klass}"


def _label_class_column(klass: Union[int, str]):
    return f"label_{klass}"


def _get_classes_for_weighted_categorical(
    df: pd.DataFrame, feature_column: str, feature_id: int
) -> List[Union[int, str]]:
    prefix = f"{feature_column}_{feature_id}_c_"
    classes = [
        sys.intern(column[len(prefix) :])
        for column in df.columns.values
        if column.startswith(prefix)
    ]
    if "int_weighted" in feature_column:
        return [int(klass) for klass in classes]
    # pyre-fixme[7]: Expected `List[Union[int, str]]` but got `List[str]`.
    return classes


def filter_empty_feature_values(batch: pd.DataFrame, features):
    column_to_feature_ids = _get_column_to_feature_ids(features)
    feature_column_set = {
        f"{column}_{feature_id}"
        for column, feature_ids in column_to_feature_ids.items()
        for feature_id in feature_ids
    }
    for column_name in batch.columns:
        if column_name in feature_column_set:
            batch = batch[batch[column_name].notnull()]
    return batch


def apply_presence_vector(features: List[Any], presence: List[bool]) -> List[Any]:
    """
    Sets values that are False in 'presence' to None in 'features'.
    """
    assert len(features) == len(presence)
    for j in (np.array(presence) == False).nonzero()[0]:  # noqa
        features[j] = None
    return features


def get_output_feature_id(transformer) -> int:
    if not transformer.task_type:
        raise Exception("Empty task_type")
    names = transformer.task_type.get_output_feature_names()
    if len(names) != 1:
        raise AssertionError(f"Expect only one output feature found: {names}")
    return transformer.get_output_features()[names[0]].id


def poisson_bootstrap_tp_fp_fn_tn(
    bundle: Tuple[float, List[Tuple[float, float, float, int]]],
) -> List[np.ndarray]:
    flow_init.initFacebook(sys.argv[0], [])
    threshold, data = bundle
    TP = np.zeros((N_BOOTSTRAPS))
    FP = np.zeros((N_BOOTSTRAPS))
    FN = np.zeros((N_BOOTSTRAPS))
    TN = np.zeros((N_BOOTSTRAPS))
    p_sample_no_weights = np.random.poisson(1, N_BOOTSTRAPS)
    for current_label, current_predict, weight, index in data:
        np.random.seed(index)
        current_predict += np.random.normal(0, 0.01, 1)
        current_predict = int(np.clip(current_predict, 0, 1) > threshold)
        ## sample from poisson for every tenth sample to make it faster
        ## otherwise use the already sampled
        if index % 3 == 0:
            p_sample_no_weights = np.random.poisson(1, N_BOOTSTRAPS)
        p_sample = p_sample_no_weights * weight

        if current_label == 1 and current_predict == 1:
            TP += p_sample
        elif current_label == 1 and current_predict == 0:
            FN += p_sample
        elif current_label == 0 and current_predict == 1:
            FP += p_sample
        elif current_label == 0 and current_predict == 0:
            TN += p_sample

    return [TP, FP, FN, TN]
