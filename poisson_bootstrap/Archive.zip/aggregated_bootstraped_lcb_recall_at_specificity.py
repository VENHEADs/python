#!/usr/bin/env python3
# pyre-strict
"""
Recall at specificity aggregated on user level implementation
with calculation of the threshold through 99% lower confidence bound
"""

import collections
import multiprocessing as mp
import os
import sys
from typing import Dict, Iterable, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from fblearner.flow.api import types
from fblearner.flow.projects.fluent2.definition.evaluation import (
    EvaluationQuery,
    AggregatedBootstrappedLCBRecallAtSpecificityMetric as AggregatedBootstrappedLCBRecallAtSpecificityDefinition,
)
from fblearner.flow.projects.fluent2.definition.task_type import (
    ExclusiveTwoClassPredictionTaskType,
)
from fblearner.flow.projects.fluent2.definition.transformer import Transformer
from fblearner.flow.projects.fluent2.workflows import const
from fblearner.flow.projects.fluent2.workflows.evaluation.metric import Metric
from fblearner.flow.projects.fluent2.workflows.evaluation.util import (
    get_feature_values,
    get_valid_scores,
    poisson_bootstrap_tp_fp_fn_tn,
)
from fblearner.flow.util.python_utils import PickleableLogger as Logger, static

np.random.seed(42)
log = Logger(__name__)


@static
class AggregatedBootstrappedLCBRecallAtSpecificityMetric(Metric):
    @classmethod
    def _compute(
        cls,
        metric: AggregatedBootstrappedLCBRecallAtSpecificityDefinition,
        transformer: Transformer,
        query_to_evaluation_set: Dict[EvaluationQuery, pd.DataFrame],
    ) -> const.MetricUnionType:
        return cls._compute_all([metric], transformer, query_to_evaluation_set)[
            metric.get_name()
        ]

    @classmethod
    # pyre-fixme[14]: `_compute_all` overrides method defined in `Metric`
    #  inconsistently.
    # pyre-fixme[15]: `_compute_all` overrides method defined in `Metric`
    #  inconsistently.
    def _compute_all(
        cls,
        metrics: Iterable[AggregatedBootstrappedLCBRecallAtSpecificityDefinition],
        transformer: Transformer,
        query_to_evaluation_set: Dict[EvaluationQuery, pd.DataFrame],
    ) -> Dict[str, const.MetricUnionType]:
        # Pack the metrics into groups:
        metric_name_to_metrics = {}
        for reverse_label in [True, False]:
            for weighted in [True, False]:
                compatible_metrics = [
                    metric
                    for metric in metrics
                    if metric.reverse_label == reverse_label
                    and metric.weighted == weighted
                ]
                if compatible_metrics:
                    results = cls._compute_compatible_metrics(
                        compatible_metrics, transformer, query_to_evaluation_set
                    )
                    if results:
                        metric_name_to_metrics.update(results)
        return metric_name_to_metrics

    @classmethod
    def _compute_compatible_metrics(
        cls,
        metrics: Sequence[AggregatedBootstrappedLCBRecallAtSpecificityDefinition],
        transformer: Transformer,
        query_to_evaluation_set: Dict[EvaluationQuery, pd.DataFrame],
    ) -> Optional[Dict[str, const.MetricUnionType]]:
        if len({metric.reverse_label for metric in metrics}) > 1:
            raise Exception(
                "All AggregatedBootstrappedLCBRecallAtSpecificityMetric must have same reverse_label."
            )
        if len({metric.weighted for metric in metrics}) > 1:
            raise Exception(
                "All AggregatedBootstrappedLCBRecallAtSpecificityMetric must have same value for 'weighted'."
            )

        if isinstance(transformer.task_type, ExclusiveTwoClassPredictionTaskType):
            return cls.compute_exclusive_two_class(
                metrics, transformer, query_to_evaluation_set
            )
        return None

    @classmethod
    def compute_exclusive_two_class(
        cls,
        metrics: Sequence[AggregatedBootstrappedLCBRecallAtSpecificityDefinition],
        transformer: Transformer,
        query_to_evaluation_set: Dict[EvaluationQuery, pd.DataFrame],
    ) -> Dict[str, const.MetricUnionType]:
        """
        Calculate noisy Poisson bootstrap. Because of the added noise, it might be
        that the predicted value is > 1.0
        Because of this and threshold exploration It  might be  that threshold is > 1.0
        However, in reality, we do not need a threshold higher than 1.0, and we clip it to 1.0
        """
        metrics_to_query_name_to_float_with_threshold = collections.defaultdict(dict)
        for query, evaluation_set in query_to_evaluation_set.items():

            if "training" in query.get_name() and metrics[0].exclude_train:
                for metric in metrics:
                    (precision, recall, threshold,) = (
                        0,
                        0,
                        0,
                    )
                    metrics_to_query_name_to_float_with_threshold[metric.get_name()][
                        query.get_name()
                    ] = types.STRUCT(
                        value=types.DOUBLE,
                        threshold=types.DOUBLE,
                        precision=types.DOUBLE,
                    ).new(
                        value=recall, threshold=threshold, precision=precision
                    )
                continue

            feature_id = transformer.get_output_features().score.id
            labels = evaluation_set.label.values
            scores = get_valid_scores(
                get_feature_values(evaluation_set, "float_features", feature_id)
            )

            if metrics[0].reverse_label:
                labels, scores = 1 - np.array(labels), -(np.array(scores))

            aggr_evaluation_set = pd.DataFrame({"label": labels, "score": scores})

            weights = None
            if metrics[0].weighted and "weight" in evaluation_set:
                weights = evaluation_set.weight.values
                aggr_evaluation_set.insert(0, "weight", weights)

            if "session_id" in evaluation_set:
                session_id = evaluation_set.session_id.values
                aggr_evaluation_set.insert(0, "session_id", session_id)
                aggr_evaluation_set = aggr_evaluation_set.groupby(["session_id"]).agg(
                    "max"
                )

            aggr_labels = aggr_evaluation_set.label.values.astype(np.int8)
            aggr_scores = aggr_evaluation_set.score.values

            if weights is not None:
                weights = aggr_evaluation_set.weight.values
            else:
                weights = np.ones(len(aggr_labels))

            for metric in metrics:
                (specificity, recall, threshold,) = cls._compute_best_threshold(
                    metric, aggr_labels, aggr_scores, weights
                )
                metrics_to_query_name_to_float_with_threshold[metric.get_name()][
                    query.get_name()
                ] = types.STRUCT(
                    value=types.DOUBLE, threshold=types.DOUBLE, specificity=types.DOUBLE
                ).new(
                    value=recall, threshold=threshold, specificity=specificity
                )

        return {
            metric.get_name(): const.METRIC_UNION_TYPE.new(
                floats_with_thresholds=metrics_to_query_name_to_float_with_threshold[
                    metric.get_name()
                ]
            )
            for metric in metrics
        }

    @classmethod
    def _compute_best_threshold(
        cls,
        metric: AggregatedBootstrappedLCBRecallAtSpecificityDefinition,
        aggr_labels: np.ndarray,
        aggr_scores: np.ndarray,
        weights: np.ndarray,
    ) -> Tuple[float, float, float]:

        cpu_to_use = np.max([np.array(os.cpu_count()) - 1, 1])
        mp.set_start_method("spawn", force=True)
        total_samples = len(aggr_labels)
        chunk_size = 20000
        epsilon = sys.float_info.epsilon
        min_specificity = metric.min_specificity

        n_changes = 0
        specificity_lcb = 1.0
        step = 0.05
        coef = 1.0
        iters = 0
        threshold = 0.81
        # If 0.81 is too low, it will take eight iterations to reach the maximum threshold
        # with each step of 0.025. In the case of non-monotonic functions, this is a fine enough grid
        # with enough space to explore. If it is too high, it will reach the bottom in no more than
        # 17 steps, bounce back + 2 iterations, bounce back + 2 steps and bounce back + 2 iterations.
        # In theory, 23 steps are enough in the worst case, hence condition iters < 24 on line 196
        # as n additional insurance. The first situation is more realistic, and I choose 0.81 to
        # fit this case. If everything is ok, it has to take to more than 8 + 2 +2 +2 steps,
        # with enough space for exploration
        final_results = []

        while (n_changes < 3 or specificity_lcb < min_specificity) and iters < 18:
            generator = (
                (
                    threshold,
                    [
                        (
                            aggr_labels[x + y],
                            aggr_scores[x + y],
                            weights[x + y],
                            x + y,
                        )
                        for x in range(chunk_size)
                        if x + y < total_samples
                    ],
                )
                for y in range(0, total_samples, chunk_size)
            )

            with mp.Pool(processes=cpu_to_use) as pool:
                stat_list = list(pool.imap(poisson_bootstrap_tp_fp_fn_tn, generator))

            TP, FP, FN, TN = np.sum(stat_list, 0)
            specificity = TN / (TN + FP + epsilon)
            recall = TP / (TP + FN + epsilon)
            recall_lcb = np.percentile(recall, 0.5)
            specificity_old = specificity_lcb
            specificity_lcb = np.percentile(specificity, 0.5)

            if specificity_lcb >= min_specificity and threshold < 1:
                final_results.append((specificity_lcb, recall_lcb, threshold))

            if (
                specificity_lcb < min_specificity and specificity_old < min_specificity
            ) or (
                specificity_lcb > min_specificity and specificity_old > min_specificity
            ):
                pass
            else:
                step /= 2.0
                coef *= -1.0
                n_changes += 1
            threshold -= coef * step
            iters += 1

        if len(final_results) == 0:
            specificity_lcb = 0
            recall_lcb = 0
            threshold = 1
        else:
            final_results = sorted(final_results, key=lambda x: x[1], reverse=True)
            specificity_lcb, recall_lcb, threshold = final_results[0]

        return specificity_lcb, recall_lcb, threshold
